-- SHOP GIFTORA: admin additions. Run AFTER schema.sql (SQL Editor > New query > paste > Run).

alter table public.profiles add column if not exists email text;
update public.profiles p set email = u.email from auth.users u where u.id = p.id and p.email is null;

-- Store the email on new sign-ups too
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, name, email, role) values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'name', ''), split_part(new.email, '@', 1)),
    new.email,
    case when new.raw_user_meta_data->>'role' = 'seller' then 'seller' else 'customer' end);
  return new;
end $$;

-- Admin can see every user
create policy "admin views profiles" on public.profiles for select using (public.is_admin());

-- Admin changes a user's role
create function public.set_role(p_id uuid, p_role text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Not allowed'; end if;
  if p_role not in ('customer','seller','admin') then raise exception 'Unknown role'; end if;
  if p_id = auth.uid() and p_role <> 'admin' then raise exception 'You cannot remove your own admin role'; end if;
  update profiles set role = p_role where id = p_id;
end $$;

revoke execute on function public.set_role(uuid, text) from public, anon;
grant execute on function public.set_role(uuid, text) to authenticated;

-- Make yourself the first admin (sign up in the app first, then put your email here and run):
-- update public.profiles set role = 'admin' where email = 'you@example.com';
