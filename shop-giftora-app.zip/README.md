# SHOP GIFTORA

Online marketplace: storefront, seller panel and admin panel on Supabase. All files are plain static files, no server needed.

| Page | What it does |
|---|---|
| index.html | Shop, cart, checkout, login/signup, My orders |
| seller.html | Sellers add products, update stock, update order status |
| admin.html | Admin: overview, all orders, all products, users and roles |

## Setup
1. Supabase > SQL Editor: run `schema.sql`, then run `admin.sql`.
2. For testing, turn off Authentication > Providers > Email > "Confirm email".
3. Put your Project URL and anon/publishable key in `config.js`.
4. Open `index.html` and sign up. Then edit the last line of `admin.sql` with your email and run it to become admin.
5. Host the folder on Netlify (import from this GitHub repo). Pages: `/`, `/seller.html`, `/admin.html`.

Never put the service_role key or database password in any file.
