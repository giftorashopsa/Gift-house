// Paste your Supabase values here (Supabase > Project Settings > API).
// Use the anon / publishable key only. Never put the service_role key or database password in this file.
const SUPABASE_URL = "https://kvcvcxrrsetqiyjhaian.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_k0U4XQKJzE9c4s3kTibjKw_TqJ3YaDE";
