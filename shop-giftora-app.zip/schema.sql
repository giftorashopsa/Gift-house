-- SHOP GIFTORA: Supabase schema
-- Supabase > SQL Editor > New query > paste all > Run (run once).

-- ===== Tables =====
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  role text not null default 'customer' check (role in ('customer','seller','admin'))
);

create table public.products (
  id bigint generated always as identity primary key,
  seller_id uuid references public.profiles(id) on delete set null default auth.uid(),
  name text not null,
  category text not null,
  price int not null check (price > 0),
  old_price int,
  rating numeric(2,1) not null default 4,
  emoji text not null default '📦',
  stock int not null default 20 check (stock >= 0),
  created_at timestamptz not null default now()
);

create table public.orders (
  id text primary key,
  user_id uuid references auth.users(id) on delete set null,
  name text not null,
  phone text not null,
  address text not null,
  payment text not null default 'Cash on delivery',
  total int not null,
  status smallint not null default 0 check (status between 0 and 3), -- 0 Placed, 1 Packed, 2 Out for delivery, 3 Delivered
  created_at timestamptz not null default now()
);

create table public.order_items (
  order_id text not null references public.orders(id) on delete cascade,
  product_id bigint references public.products(id) on delete set null,
  qty int not null check (qty > 0),
  price int not null
);

-- ===== Helper functions (bypass RLS safely) =====
create function public.is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin') $$;

create function public.is_seller() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role in ('seller','admin')) $$;

create function public.seller_has_order(p_id text) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from order_items oi join products p on p.id = oi.product_id
                 where oi.order_id = p_id and p.seller_id = auth.uid()) $$;

create function public.user_owns_order(p_id text) returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from orders where id = p_id and user_id = auth.uid()) $$;

-- ===== Create a profile on sign-up (role can only be customer or seller) =====
create function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, name, role) values (
    new.id,
    coalesce(nullif(new.raw_user_meta_data->>'name', ''), split_part(new.email, '@', 1)),
    case when new.raw_user_meta_data->>'role' = 'seller' then 'seller' else 'customer' end);
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- ===== Row Level Security =====
alter table public.profiles    enable row level security;
alter table public.products    enable row level security;
alter table public.orders      enable row level security;
alter table public.order_items enable row level security;

create policy "own profile"      on public.profiles for select using (id = auth.uid());

create policy "view products"    on public.products for select
  using (stock > 0 or seller_id = auth.uid() or public.is_admin());
create policy "seller adds"      on public.products for insert
  with check (seller_id = auth.uid() and public.is_seller());
create policy "seller edits"     on public.products for update
  using (seller_id = auth.uid() or public.is_admin())
  with check (seller_id = auth.uid() or public.is_admin());
create policy "seller deletes"   on public.products for delete
  using (seller_id = auth.uid() or public.is_admin());

create policy "view orders"      on public.orders for select
  using (user_id = auth.uid() or public.is_admin() or public.seller_has_order(id));

create policy "view order items" on public.order_items for select
  using (public.is_admin() or public.user_owns_order(order_id)
         or exists (select 1 from products p where p.id = product_id and p.seller_id = auth.uid()));
-- No insert/update policies on orders: orders are only created through place_order() below.

-- ===== Place an order (checks stock, adds delivery fee, works for guests too) =====
create function public.place_order(p_name text, p_phone text, p_address text, p_payment text, p_items jsonb)
returns json language plpgsql security definer set search_path = public as $$
declare
  v_id text; v_sub int := 0; v_total int; it jsonb; p products%rowtype; v_qty int;
begin
  if coalesce(trim(p_name),'') = '' or coalesce(trim(p_phone),'') = '' or coalesce(trim(p_address),'') = ''
     or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'Name, phone, address and at least one item are required';
  end if;
  loop
    v_id := 'GF-' || (floor(random() * 900000) + 100000)::int;
    exit when not exists (select 1 from orders where id = v_id);
  end loop;
  for it in select * from jsonb_array_elements(p_items) loop
    v_qty := floor((it->>'qty')::numeric)::int;
    select * into p from products where id = (it->>'id')::bigint for update;
    if not found or v_qty <= 0 then raise exception 'Invalid item in cart'; end if;
    if p.stock < v_qty then raise exception 'Only % left of %', p.stock, p.name; end if;
    v_sub := v_sub + p.price * v_qty;
  end loop;
  v_total := v_sub + case when v_sub >= 3000 then 0 else 99 end;
  insert into orders (id, user_id, name, phone, address, payment, total)
  values (v_id, auth.uid(), trim(p_name), trim(p_phone), trim(p_address), coalesce(p_payment, 'Cash on delivery'), v_total);
  for it in select * from jsonb_array_elements(p_items) loop
    v_qty := floor((it->>'qty')::numeric)::int;
    select * into p from products where id = (it->>'id')::bigint;
    update products set stock = stock - v_qty where id = p.id;
    insert into order_items values (v_id, p.id, v_qty, p.price);
  end loop;
  return json_build_object('id', v_id, 'total', v_total);
end $$;

-- ===== Track an order by its id (no login needed) =====
create function public.track_order(p_id text)
returns table (id text, status smallint, total int, created_at timestamptz)
language sql security definer set search_path = public as $$
  select o.id, o.status, o.total, o.created_at from orders o where o.id = p_id $$;

-- ===== Seller or admin updates order status =====
create function public.set_order_status(p_id text, p_status int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_status not between 0 and 3 then raise exception 'status must be 0 to 3'; end if;
  if not (public.is_admin() or public.seller_has_order(p_id)) then raise exception 'Order not found'; end if;
  update orders set status = p_status where id = p_id;
end $$;

revoke execute on all functions in schema public from public, anon, authenticated;
grant execute on function public.place_order(text,text,text,text,jsonb) to anon, authenticated;
grant execute on function public.track_order(text)                      to anon, authenticated;
grant execute on function public.set_order_status(text,int)             to authenticated;
grant execute on function public.is_admin(), public.is_seller(),
                          public.seller_has_order(text), public.user_owns_order(text) to anon, authenticated;

-- ===== Sample products (house products, no seller) =====
insert into public.products (name, category, price, old_price, rating, emoji) values
 ('Wireless earbuds','Electronics',2490,3200,4.5,'🎧'),
 ('Smart watch','Electronics',4990,6500,4.3,'⌚'),
 ('Power bank 20,000 mAh','Electronics',1890,2300,4.6,'🔋'),
 ('Denim jacket','Fashion',2790,3500,4.2,'🧥'),
 ('Running shoes','Fashion',3290,4200,4.4,'👟'),
 ('Canvas tote bag','Fashion',990,1400,4.1,'👜'),
 ('Table lamp','Home',1290,1700,4.5,'💡'),
 ('Non-stick pan','Home',1590,2100,4.4,'🍳'),
 ('Cotton bedsheet','Home',1890,2400,4.3,'🛏️'),
 ('Basmati rice 5 kg','Grocery',890,990,4.7,'🍚'),
 ('Green tea box','Grocery',450,560,4.6,'🍵'),
 ('Face serum','Beauty',1190,1600,4.2,'🧴');

-- ===== Make yourself admin (after you sign up in the app; put your email) =====
-- update public.profiles set role = 'admin'
-- where id = (select id from auth.users where email = 'you@example.com');
