// SHOP GIFTORA: Supabase helper used by index.html, seller.html and admin.html.
// Needs the supabase-js script and config.js loaded before this file.
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const ok = ({ data, error }) => { if (error) throw new Error(error.message); return data; };
const uid = async () => (await sb.auth.getUser()).data.user?.id;

const GF = {
  // ---- Storefront ----
  products({ cat, q, sort } = {}) {
    let r = sb.from("products").select("id,name,category,price,old_price,rating,emoji,stock").gt("stock", 0);
    if (cat && cat !== "All") r = r.eq("category", cat);
    if (q) r = r.ilike("name", `%${q}%`);
    const [col, asc] = { lo: ["price", true], hi: ["price", false], rt: ["rating", false] }[sort] || ["id", true];
    return r.order(col, { ascending: asc }).then(ok);
  },
  placeOrder: (o) => sb.rpc("place_order", {
    p_name: o.name, p_phone: o.phone, p_address: o.address, p_payment: o.payment, p_items: o.items,
  }).then(ok),
  track: (id) => sb.rpc("track_order", { p_id: id }).then(ok),

  // ---- Accounts ----
  signUp: (name, email, password, role = "customer") =>
    sb.auth.signUp({ email, password, options: { data: { name, role } } }).then(ok),
  signIn: (email, password) => sb.auth.signInWithPassword({ email, password }).then(ok),
  signOut: () => sb.auth.signOut(),
  async me() {
    const id = await uid();
    return id ? sb.from("profiles").select("name,role").eq("id", id).single().then(ok) : null;
  },
  async myOrders() {
    return sb.from("orders").select("id,total,status,created_at").eq("user_id", await uid())
      .order("created_at", { ascending: false }).then(ok);
  },

  // ---- Seller ----
  async sellerProducts() {
    return sb.from("products").select("*").eq("seller_id", await uid()).order("id", { ascending: false }).then(ok);
  },
  addProduct: (p) => sb.from("products").insert(p).select().single().then(ok),
  updateProduct: (id, patch) => sb.from("products").update(patch).eq("id", id).then(ok),
  deleteProduct: (id) => sb.from("products").delete().eq("id", id).then(ok),
  sellerOrders: () => sb.from("orders").select("*").order("created_at", { ascending: false }).then(ok),
  setStatus: (id, status) => sb.rpc("set_order_status", { p_id: id, p_status: status }).then(ok),

  // ---- Admin (needs admin.sql) ----
  allOrders: () => sb.from("orders").select("*").order("created_at", { ascending: false }).then(ok),
  allProducts: () => sb.from("products").select("*").order("id", { ascending: false }).then(ok),
  allUsers: () => sb.from("profiles").select("id,name,email,role").order("name").then(ok),
  setRole: (id, role) => sb.rpc("set_role", { p_id: id, p_role: role }).then(ok),
};
